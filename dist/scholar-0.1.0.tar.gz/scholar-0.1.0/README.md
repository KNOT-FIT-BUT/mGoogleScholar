mGoogleScholar
Python API module for scholar.google.cz

Try it

In ./bin/example/ you can find example app using scholar.py module.

More informations:

https://merlin.fit.vutbr.cz/nlp-wiki/index.php/Rrs_cite_comparsion
